package hybrid_app;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.pagefactory.bys.builder.AppiumByBuilder;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class baseHybrid 
{
	public  AndroidDriver driver;
	public AppiumDriverLocalService service;
	
	@BeforeClass @Test
	public void configureAppium() throws MalformedURLException
	{		
		
		Map<String, String> env= new HashMap<String, String>(System.getenv());
		env.put("ANDROID_HOME", "C:\\Users\\prasanth.sekar\\AppData\\Local\\Android\\Sdk");
		env.put("JAVA_HOME", "C:\\Program Files\\Java\\jdk-11");
		
		
		//creating appium server instance
		service = new AppiumServiceBuilder().withAppiumJS(new File("C:\\Users\\prasanth.sekar\\AppData\\Roaming\\npm\\node_modules\\appium\\build\\lib\\main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).withEnvironment(env).build();
		
		service.start();
		
		//create capabilities
		UiAutomator2Options options= new UiAutomator2Options();
		options.setDeviceName("Pixel 2 API 34"); 
		options.setApp("D:\\Appium\\Appium_exploration\\src\\main\\java\\resources\\General-Store.apk"); //Hybrid app
		//options.setPlatformName("ANDROID");
		//options.setCapability("platformVersion", "14.0");
		//options.setCapability("automationName", "UiAutomator2");
		options.setChromedriverExecutable("D:\\Basic software\\chromedriver_win32.zip\\chromedriver.exe");
				
		//creating the android driver/IOS driver
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
		
	@AfterClass
	public void tearDown() {
		driver.quit();
		service.stop();
		//stopping the service
	
	}
}
 