package hybrid_app;

import org.testng.Assert;
import org.testng.annotations.Test;

import Maven.Appium_exploration.base;
import Maven.Appium_exploration.function_methods;
import io.appium.java_client.AppiumBy;

public class generalStore extends baseHybrid{
	
	function_methods methods = new function_methods();
	
	@Test (enabled = false)	
	public void fillForm() throws InterruptedException {

		driver.findElement(AppiumBy.id("android:id/text1")).click();
		methods.scrollGestureMethod("Canada",driver);
		//driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Canada\"));")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/nameField")).sendKeys("Bella");
		//Thread.sleep(5000);
		//((HidesKeyboard)driver).hideKeyboard(); 

		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/radioFemale")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop")).click();
	}
	
	@Test 
	public void toastMessage()
	{	
		driver.findElement(AppiumBy.id("android:id/text1")).click();
		methods.scrollGestureMethod("Canada",driver);
		//driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Canada\"));")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/radioFemale")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop")).click();
		
		String toastMsg = driver.findElement(AppiumBy.xpath("(//android.widget.Toast)[1]")).getAttribute("name");
		Assert.assertEquals(toastMsg, "Please enter your name");
	}
}
