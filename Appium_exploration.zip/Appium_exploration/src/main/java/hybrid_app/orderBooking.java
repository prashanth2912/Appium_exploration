package hybrid_app;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import Maven.Appium_exploration.function_methods;
import io.appium.java_client.AppiumBy;

public class orderBooking extends baseHybrid{
	String product = "Air Jordan 9 Retro";

	@Test
	public void order() throws InterruptedException {

		driver.findElement(AppiumBy.id("android:id/text1")).click();
		function_methods methods = new function_methods();
		methods.scrollGestureMethod("Canada",driver);
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/nameField")).sendKeys("Bella");

		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/radioFemale")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/btnLetsShop")).click();

		methods.scrollGestureMethod(product, driver);

		int count = driver.findElements(AppiumBy.id("com.androidsample.generalstore:id/productName")).size();
		for(int i=0;i<count;i++)
		{
			String text = driver.findElements(AppiumBy.id("com.androidsample.generalstore:id/productName")).get(i).getText();

			if(text.equalsIgnoreCase(product))
			{
				driver.findElements(AppiumBy.id("com.androidsample.generalstore:id/productAddCart")).get(i).click();
			}
		}
		
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
		driver.findElement(AppiumBy.id("com.androidsample.generalstore:id/btnProceed")).click();
		Thread.sleep(3000);
		Set<String> contextNames = driver.getContextHandles();
		
		for(String context : contextNames)
			System.out.println(context);
		
		driver.context("WEBVIEW_com.androidsample.generalstore");
		
		Thread.sleep(20000);
		driver.findElement(By.name("q")).sendKeys("amazon",Keys.ENTER); 
		Thread.sleep(3000);
	}
}
