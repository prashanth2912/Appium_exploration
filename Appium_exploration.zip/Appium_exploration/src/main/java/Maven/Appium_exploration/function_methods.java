package Maven.Appium_exploration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.Test;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;

@Test
public class function_methods {
	
	public void scrollGestureMethod(String ele, AndroidDriver driver)
	{
		driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"" + ele + "\"));")).click();;
	}
	
	public void  swipeGestureMethod(WebElement element, AndroidDriver driver) {
		((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", 
				ImmutableMap.of("elementId",
						((RemoteWebElement) element).getId(), 
						"duration", 3000, 
						"direction", "left", 
						"percent", 0.75));
	}

	public void longClickGestureMethod(WebElement element, AndroidDriver driver) {
		// TODO Auto-generated method stub
		((JavascriptExecutor) driver).executeScript("mobile: longClickGesture", ImmutableMap.of(
			    "elementId", ((RemoteWebElement) element).getId()),"duration", 3000);
	}

}
