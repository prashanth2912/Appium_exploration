package Maven.Appium_exploration;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class swipeGesture extends base {

	@Test
	public void swipeTest() {

		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Gallery")).click();
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc='1. Photos']")).click();

		// Before performing the swipe action
		WebElement firstImage = driver.findElement(AppiumBy.xpath("(//android.widget.ImageView)[1]"));
		String firstImageValue = firstImage.getAttribute("focusable");
		assertEquals(firstImageValue, "true");

		// Performing the swap action
		function_methods methods = new function_methods();
		methods.swipeGestureMethod(firstImage, driver);
		
		// after performing the swap
		String secondImageValue = driver.findElement(AppiumBy.xpath("(//android.widget.ImageView)[1]")).getAttribute("focusable");
		assertEquals(secondImageValue, "false");

	}
}
