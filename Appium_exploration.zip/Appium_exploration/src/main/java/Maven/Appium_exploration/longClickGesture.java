package Maven.Appium_exploration;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

@Test
public class longClickGesture extends base {

	public void longClick() {

		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		driver.findElement(AppiumBy.accessibilityId("Expandable Lists")).click();
		driver.findElement(AppiumBy.accessibilityId("1. Custom Adapter")).click();

		WebElement longClk = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text='Cat Names']"));

		function_methods methods = new function_methods();
		methods.longClickGestureMethod(longClk,driver);

		WebElement element = driver.findElement(AppiumBy.xpath("//android.widget.TextView[@resource-id=\"android:id/title\"]"));
		
		assertEquals(element.getText(), "Sample menu");
	}

}
