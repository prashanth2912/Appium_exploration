package Maven.Appium_exploration;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

@Test
public class scrollDemoGesture extends base{

	public void scrollTest() {
		
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		
		//for navigating into a specific element
		String text = "Spinner";
		function_methods methods = new function_methods();
		methods.scrollGestureMethod(text, driver);
		
		//for navigating until the end of page is received
		/*boolean canScrollMore ;
		do {
			canScrollMore = (Boolean) ((JavascriptExecutor) driver).executeScript("mobile: scrollGesture", ImmutableMap.of(
		    "left", 100, "top", 100, "width", 200, "height", 200,
		    "direction", "down",
		    "percent", 1.0
		));
		}
		while(canScrollMore);*/
	}
}
