package Maven.Appium_exploration;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

@Test
public class apiDesomsapkautomation extends base {
	
	public void setWifiTest() {
		WebElement preference = driver.findElement(AppiumBy.accessibilityId("Preference"));
		preference.click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc='3. Preference dependencies']")).click();
		driver.findElement(AppiumBy.id("android:id/checkbox")).click();
		driver.findElement(AppiumBy.xpath("(//android.widget.RelativeLayout)[2]")).click();
		driver.findElement(AppiumBy.id("android:id/edit")).sendKeys("no123");
		driver.findElement(AppiumBy.id("android:id/button1")).click();	
				
	}

}
